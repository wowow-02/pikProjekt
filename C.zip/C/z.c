#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

#define MAX_CANDIDATES 1000 // Maksimalni broj pronađenih kandidata

void AlgoritamZ(char *ref, char *sub, int tolerance, char *kandidati[]){
    int ref_len = strlen(ref);
    int sub_len = strlen(sub); 
    char *concatenated = (char *)malloc(ref_len + sub_len + 2);
    strcpy(concatenated, sub);
    concatenated[sub_len] = '$'; // Specijalni separator između sub i ref
    strcpy(concatenated + sub_len + 1, ref);
    //int concatenated_len = ref_len + sub_len + 1;
    int concatenated_len = strlen(concatenated);
    printf(concatenated);
    int *Z = (int *)malloc(concatenated_len * sizeof(int));
    //int Z[concatenated_len];
    // Inicijalizacija polja Z 
    Z[0] = 0;
    //left i right odreduju prozor koji matcha s prefixom
    int left = 0;
    int right = 0;
    int candidate_count = 0;
    for (int k = 1; k < concatenated_len; ++k){
        //Ako je k > right, nema matcha, Z[k] se racuna:
        if (k > right) {
            left = right = k;
            while (right < concatenated_len && concatenated[right - left] == concatenated[right]){
                right++;
            }
            Z[k] = right - left;
            right--;
        } else{
            //k1 je broj koji odgovara matchu izmedu left i right
            int k1 = k - left;
            //Z[k1] < od preostalog intervala, onda je on Z[k]
            if (Z[k1] < right - k + 1){
                Z[k] = Z[k1];
            } else {
                left = k;
                while (right < concatenated_len && concatenated[right - left] == concatenated[right]){
                    right++;
                }
                Z[k] = right - left;
                right--;
            }
        }
        // Pronalazak podniza unutar ref uz uvažavanje tolerancije
        if (Z[k] == sub_len /*&& k <= ref_len */&& k >= sub_len + 1 /*&& k + sub_len - 1 <= concatenated_len*/){
            int error_count = 0;
            for (int i = 0; i < sub_len; ++i) {
                if (sub[i] != ref[k + i - sub_len - 1]) {
                    error_count++;
                }
            }
            if (error_count <= tolerance) {
                kandidati[candidate_count++] = &ref[k - sub_len - 1];
                printf("Pattern found at position: %d\n",k - sub_len - 1);
            }
        }
    }
    free(concatenated);
    free(Z);
}
int main(){
    char *ref = "GGAATCGATCGATCGATCG"; 
    char *sub = "ATCG";
    int tolerance = 1;
    char *kandidati[MAX_CANDIDATES]; // Polje za kandidate
    for (int i = 0; i < MAX_CANDIDATES; ++i){
        kandidati[i] = NULL;
    }
    AlgoritamZ(ref, sub, tolerance, kandidati);
    // Ispis pronađenih kandidata
    printf("Pronađeni kandidati:\n");
    for (int i = 0; kandidati[i] != NULL; ++i){
        printf("%s\n", kandidati[i]);
    }
}