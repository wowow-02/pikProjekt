#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

#define ALPHABET_SIZE 4
#define PRIME 101

int hash(char *str, int len){
    int hash_value = 0;
    for (int i = 0; i < len; ++i){
        //hash_value = (hash_value * ALPHABET_SIZE + (str[i] - 'A')) % PRIME;
        hash_value = (hash_value * ALPHABET_SIZE + str[i]) % PRIME; 
    }
    return hash_value; 
}
//DODANO
int power(int x, int y) {
    int result = 1;
    for (int i = 0; i < y; i++) {
        result = (result * x) % PRIME;
    }
    return result;
}
//Do TUD
int rehash(int old_hash, char old_char, char new_char, int len){
    //int new_hash = (old_hash - (old_char - 'A') * len) % PRIME; 
    //new_hash = (new_hash * ALPHABET_SIZE + (new_char - 'A')) % PRIME;
    int new_hash = (old_hash - (old_char * power(ALPHABET_SIZE, len - 1))) % PRIME;
    new_hash = (new_hash * ALPHABET_SIZE + new_char) % PRIME;
    return (new_hash < 0) ? new_hash + PRIME : new_hash;
}
void RabinKarp(char *ref, char *sub, int tolerance, char **kandidati){
    int ref_len = strlen(ref);
    int sub_len = strlen(sub);
    int ref_hash = hash(ref, sub_len);
    int sub_hash = hash(sub, sub_len);

    for (int i = 0; i <= ref_len - sub_len; ++i) {
        if (ref_hash == sub_hash){
            int error_count = 0;
            for (int j = 0; j < sub_len; ++j){
                //char pomocnaref = ref[i+j];//ovo za debug
                //char pomocnasub = ref[j];//pomocna
                if (ref[i + j] != sub[j]){
                    error_count++;
                }
            }
            if(error_count <= tolerance){
                kandidati[i] = &ref[i];
                printf("Pattern found at position: %d\n",i);
            }
        }
        if (i < ref_len - sub_len){
            ref_hash = rehash(ref_hash, ref[i], ref[i + sub_len], sub_len);
        }
    }
} 
int main(){
    char *ref = "AGAGTGATCGAGTGCGTCGAGTG";
    char *sub = "GAGTG";
    int tolerance = 1;
    int ref_len = strlen(ref);
    char **kandidati = (char **)malloc(ref_len * sizeof(char *));
    for (int i = 0; i < ref_len; ++i){
        kandidati[i] = NULL;
    }
    RabinKarp(ref, sub, tolerance, kandidati);
    printf("Pronađeni kandidati:\n");
    for (int i = 0; i < ref_len/*kandidati[i] != NULL*/; ++i){
        printf("%s\n",kandidati[i]);
    }
    free(kandidati);
    return 0;
}