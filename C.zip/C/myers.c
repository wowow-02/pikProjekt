#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

#define ALPHABET_SIZE 4 

int min(int a, int b) { 
    return (a < b) ? a : b; 
} 

void Myers(char *ref, char *sub, int tolerance, char **kandidati) { 
    int ref_len = strlen(ref);
    int sub_len = strlen(sub); 
    int *prev_row = (int *)malloc((ref_len + 1) * sizeof(int)); 
    int *curr_row = (int *)malloc((ref_len + 1) * sizeof(int));
    int i, j; 

    for (i = 0; i <= ref_len; ++i){
        prev_row[i] = i;
    }
    int candidate_count = 0; 

    for (i = 0; i < sub_len; ++i){
        curr_row[0] = i + 1; 
        for (j = 0; j < ref_len; ++j) { 
            int insertion = prev_row[j + 1] + 1; 
            int deletion = curr_row[j] + 1; 
            int match = prev_row[j];
            if (sub[i] != ref[j]) { 
                match += 1;
            }
            curr_row[j + 1] = min(min(insertion, deletion), match);
        }
        if (curr_row[ref_len] <= tolerance) { 
            kandidati[candidate_count++] = &ref[i - ref_len + 1];
            printf("Pronađen kandidat na mjestu");
        }
        int *temp = prev_row;
        prev_row = curr_row;
        curr_row = temp;
    }
    free(prev_row); 
    free(curr_row);
}
int main() { 
    char *ref = "ATCGATCGATCGATCG"; 
    char *sub = "ATCG"; 
    int tolerance = 1; 
    int ref_len = strlen(ref); 
    char **kandidati = (char **)malloc(ref_len * sizeof(char *)); 
    for (int i = 0; i < ref_len; ++i) { 
        kandidati[i] = NULL; 
    }
    Myers(ref, sub, tolerance, kandidati);
    printf("Pronađeni kandidati:\n"); 
    for (int i = 0; kandidati[i] != NULL; ++i) { 
        printf("%s\n", kandidati[i]); 
    }
    free(kandidati); 
    return 0;
} 