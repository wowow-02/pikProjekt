package main

import (
	"fmt"
)

const MAX_CANDIDATES = 1000

func AlgoritamZ(input []string, sub string, tolerance int, ch *chan string) {
	for _, ref := range input {
		refLen, subLen := len(ref), len(sub)
		concatenated := make([]byte, refLen+subLen+2)
		copy(concatenated, sub)
		concatenated[subLen] = '$' // Specijalni separator između sub i ref
		copy(concatenated[subLen+1:], ref)
		concatenatedLen := len(concatenated)

		Z := make([]int, concatenatedLen)
		left, right := 0, 0
		candidateCount := 0

		for k := 1; k < concatenatedLen; k++ {
			// Ako je k > right, nema matcha, Z[k] se racuna:
			if k > right {
				left, right = k, k
				for right < concatenatedLen && concatenated[right-left] == concatenated[right] {
					right++
				}
				Z[k] = right - left
				right--
			} else {
				// k1 je broj koji odgovara matchu izmedu left i right
				k1 := k - left
				// Z[k1] < od preostalog intervala, onda je on Z[k]
				if Z[k1] < right-k+1 {
					Z[k] = Z[k1]
				} else {
					left = k
					for right < concatenatedLen && concatenated[right-left] == concatenated[right] {
						right++
					}
					Z[k] = right - left
					right--
				}
			}

			//svi kandidati se stavljaju u kanal ch <- kandidat
			// Pronalazak podniza unutar ref uz uvažavanje tolerancije
			if Z[k] == subLen && k >= subLen+1 && k+subLen-1 <= refLen+subLen {
				errorCount := 0
				for i := 0; i < subLen; i++ {
					if sub[i] != ref[k+i-subLen-1] {
						errorCount++
					}
				}
				if errorCount <= tolerance {
					startIndex := k - subLen - 1
					substring := ref[startIndex : startIndex+subLen]
					*ch <- substring //TODO tu ne znam sta proslijedit, vidim da je u izvornom kodu bio substring al nema mi to smisla kao kandidat?!
					fmt.Printf("Pattern found at position: %d\n", startIndex)
					candidateCount++
				}
			}
		}
	}
}
func main() {
	ref := []string{"GGAATCGATCGATCGATCG", "CGATCGATCGATCGATCGATCG"}
	sub := "ATCG"
	tolerance := 1
	kandidati := make(chan string, MAX_CANDIDATES)

	go AlgoritamZ(ref, sub, tolerance, &kandidati)

	fmt.Println("Pronađeni kandidati:")
	for candidate := range kandidati {
		fmt.Println(candidate)
	}
	close(kandidati)
}
