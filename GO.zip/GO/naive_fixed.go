func Myers(ref []string, sub string, tolerance int, kandidati *chan string) {
	refLen, subLen := len(ref), len(sub)
	for _, refString := range ref {
		for i := 0; i <= refLen-subLen; i++ {
			diffCount := 0

			for j := 0; j < subLen; j++ {
				if sub[j] != refString[i+j] {
					diffCount++
				}

				if diffCount > tolerance {
					break
				}
			}

			if diffCount <= tolerance {
				*kandidati <- refString[i : i+subLen]
				fmt.Printf("Pattern found at position: %d\n", i)
			}
		}
	}
}
