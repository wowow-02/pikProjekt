package main

import (
	"fmt"
)

const (
	ALPHABET_SIZE = 4
	PRIME         = 101
)

func hash(str string, length int) int {
	hashValue := 0
	for i := 0; i < length; i++ {
		hashValue = (hashValue*ALPHABET_SIZE + int(str[i])) % PRIME
	}
	return hashValue
}

func power(x, y int) int {
	result := 1
	for i := 0; i < y; i++ {
		result = (result * x) % PRIME
	}
	return result
}

func rehash(oldHash int, oldChar, newChar byte, length int) int {
	newHash := (oldHash - int(oldChar)*power(ALPHABET_SIZE, length-1)) % PRIME
	newHash = (newHash*ALPHABET_SIZE + int(newChar)) % PRIME
	if newHash < 0 {
		newHash += PRIME
	}
	return newHash
}

func RabinKarp(ref, sub string, tolerance int, kandidati []*string) {
	refLen, subLen := len(ref), len(sub)
	refHash, subHash := hash(ref[:subLen], subLen), hash(sub, subLen)

	for i := 0; i <= refLen-subLen; i++ {
		if refHash == subHash {
			errorCount := 0
			for j := 0; j < subLen; j++ {
				if ref[i+j] != sub[j] {
					errorCount++
				}
			}
			if errorCount <= tolerance {
				// Convert the substring to a string and take its address
				substring := ref[i : i+subLen]
				kandidati[i] = &substring
				fmt.Printf("Pattern found at position: %d\n", i)
			}
		}
		if i < refLen-subLen {
			refHash = rehash(refHash, ref[i], ref[i+subLen], subLen)
		}
	}
}

func main() {
	ref := "AGAGTGATCGAGTGCGTCGAGTG"
	sub := "GAGTG"
	tolerance := 1
	refLen := len(ref)
	kandidati := make([]*string, refLen)
	for i := 0; i < refLen; i++ {
		kandidati[i] = nil
	}

	RabinKarp(ref, sub, tolerance, kandidati)

	fmt.Println("Pronađeni kandidati:")
	for _, k := range kandidati {
		if k != nil {
			fmt.Println(*k)
		}
	}
}
