package main

import (
	"fmt"
)

func Myers(ref, sub string, tolerance int) []string {
	refLen := len(ref)
	subLen := len(sub)

	var kandidati []string

	for i := 0; i <= refLen-subLen; i++ {
		diffCount := 0

		for j := 0; j < subLen; j++ {
			if sub[j] != ref[i+j] {
				diffCount++
			}

			// If the number of differences exceeds tolerance, break the loop
			if diffCount > tolerance {
				break
			}
		}

		// If the number of differences does not exceed tolerance, add the substring to candidates
		if diffCount <= tolerance {
			kandidati = append(kandidati, ref[i:i+subLen])
		}
	}

	return kandidati
}

func main() {
	ref := "ATCGATCGATCGATCG"
	sub := "ATCG"
	tolerance := 1

	kandidati := Myers(ref, sub, tolerance)

	fmt.Println("Pronađeni kandidati:")
	for _, kandidat := range kandidati {
		fmt.Println(kandidat)
	}
}
