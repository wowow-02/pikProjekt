package main

import (
	"fmt"
)

const (
	ALPHABET_SIZE  = 4
	PRIME          = 101
	MAX_CANDIDATES = 1000
)

func hash(str string, length int) int {
	hashValue := 0
	for i := 0; i < length; i++ {
		hashValue = (hashValue*ALPHABET_SIZE + int(str[i])) % PRIME
	}
	return hashValue
}

func power(x, y int) int {
	result := 1
	for i := 0; i < y; i++ {
		result = (result * x) % PRIME
	}
	return result
}

func rehash(oldHash int, oldChar, newChar byte, length int) int {
	newHash := (oldHash - int(oldChar)*power(ALPHABET_SIZE, length-1)) % PRIME
	newHash = (newHash*ALPHABET_SIZE + int(newChar)) % PRIME
	if newHash < 0 {
		newHash += PRIME
	}
	return newHash
}

func RabinKarp(ref []string, sub string, tolerance int, kandidati *chan string) {
	subLen := len(sub)
	for _, refString := range ref {
		refLen := len(refString)
		refHash := hash(refString, subLen)
		subHash := hash(sub, subLen)

		for i := 0; i <= refLen-subLen; i++ {
			if refHash == subHash {
				errorCount := 0
				for j := 0; j < subLen; j++ {
					if refString[i+j] != sub[j] {
						errorCount++
					}
				}
				if errorCount <= tolerance {
					*kandidati <- refString[i : i+subLen]
					//*kandidati = append(*kandidati, refString[i:i+subLen])
					fmt.Printf("Pattern found at position: %d in ref: %s\n", i, refString)
				}
			}
			if i < refLen-subLen {
				refHash = rehash(refHash, refString[i], refString[i+subLen], subLen)
			}
		}
	}
}

func main() {
	ref := []string{"AGAGTGATCGAGTGCGTCGAGTG", "CGAGTGATCGAGTGTAGAGTG", "GAGTGTAGAGTGGAGTG"}
	sub := "GAGTG"
	tolerance := 1
	kandidati := make(chan string, MAX_CANDIDATES)

	go RabinKarp(ref, sub, tolerance, &kandidati)

	fmt.Println("Pronađeni kandidati:")
	for candidate := range kandidati {
		fmt.Println(candidate)
	}
	close(kandidati)
}
