package main

import (
	"fmt"
)

const MAX_CANDIDATES = 1000 // Maksimalni broj pronađenih kandidata

func AlgoritamZ(ref, sub string, tolerance int, kandidati []*string) {
	refLen, subLen := len(ref), len(sub)
	concatenated := make([]byte, refLen+subLen+2)

	copy(concatenated, sub)
	concatenated[subLen] = '$' // Specijalni separator između sub i ref
	copy(concatenated[subLen+1:], ref)
	concatenatedLen := len(concatenated)

	Z := make([]int, concatenatedLen)
	left, right := 0, 0
	candidateCount := 0

	for k := 1; k < concatenatedLen; k++ {
		// Ako je k > right, nema matcha, Z[k] se racuna:
		if k > right {
			left, right = k, k
			for right < concatenatedLen && concatenated[right-left] == concatenated[right] {
				right++
			}
			Z[k] = right - left
			right--
		} else {
			// k1 je broj koji odgovara matchu izmedu left i right
			k1 := k - left
			// Z[k1] < od preostalog intervala, onda je on Z[k]
			if Z[k1] < right-k+1 {
				Z[k] = Z[k1]
			} else {
				left = k
				for right < concatenatedLen && concatenated[right-left] == concatenated[right] {
					right++
				}
				Z[k] = right - left
				right--
			}
		}

		// Pronalazak podniza unutar ref uz uvažavanje tolerancije
		if Z[k] == subLen && k >= subLen+1 && k+subLen-1 <= refLen+subLen {
			errorCount := 0
			for i := 0; i < subLen; i++ {
				if sub[i] != ref[k+i-subLen-1] {
					errorCount++
				}
			}
			if errorCount <= tolerance {
				startIndex := k - subLen - 1
				substring := ref[startIndex : startIndex+subLen]
				kandidati[candidateCount] = &substring
				fmt.Printf("Pattern found at position: %d\n", startIndex)
				candidateCount++
			}
		}
	}

	// free(concatenated) and free(Z) are not necessary in Go
}

func main() {
	ref := "GGAATCGATCGATCGATCG"
	sub := "ATCG"
	tolerance := 1
	kandidati := make([]*string, MAX_CANDIDATES)

	for i := 0; i < MAX_CANDIDATES; i++ {
		kandidati[i] = nil
	}

	AlgoritamZ(ref, sub, tolerance, kandidati)

	// Ispis pronađenih kandidata
	fmt.Println("Pronađeni kandidati:")
	for _, k := range kandidati {
		if k != nil {
			fmt.Println(*k)
		}
	}
}
