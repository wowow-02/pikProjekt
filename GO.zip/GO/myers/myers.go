package main

import (
	"fmt"
)

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func Myers(ref, sub string, tolerance int) []string {
	refLen := len(ref)
	subLen := len(sub)

	prevRow := make([]int, refLen+1)
	currRow := make([]int, refLen+1)

	for i := 0; i <= refLen; i++ {
		prevRow[i] = i
	}

	var candidates []string

	for i := 0; i < subLen; i++ {
		currRow[0] = i + 1
		for j := 0; j < refLen; j++ {
			insertion := prevRow[j+1] + 1
			deletion := currRow[j] + 1
			match := prevRow[j]
			if sub[i] != ref[j] {
				match += 1
			}
			currRow[j+1] = min(min(insertion, deletion), match)
		}

		if currRow[refLen] <= tolerance {
			startIndex := i - refLen + 1
			if startIndex < 0 {
				startIndex = 0
			}
			candidates = append(candidates, ref[startIndex:i+1])
			fmt.Printf("Pronađen kandidat na mjestu %d: %s\n", startIndex, candidates[len(candidates)-1])
		}
	}

	return candidates
}

func main() {
	ref := "ATCGATCGATCGATCG"
	sub := "ATCG"
	tolerance := 1

	candidates := Myers(ref, sub, tolerance)

	fmt.Println("Pronađeni kandidati:")
	for _, candidate := range candidates {
		fmt.Println(candidate)
	}
}